<template>
  <div class="sidebar">
    

  </div>
  <div class="main">
    <router-view/>
  </div>    
</template>

<script>
export default { 
    data() {
      return {
        urlList : [
          {path: '/example/InputForm',          name: 'InputForm'},
          {path: '/example/ConditionNumber',    name: 'ConditionNumber'},
          {path: '/example/ToggleColor',        name: 'ToggleColor'},
          {path: '/example/SortSearch',         name: 'SortSearch'},
          {path: '/example/CRUD',               name: 'CRUD'},
          {path: '/example/BasicBinding',       name: 'BasicBinding'},
          {path: '/example/BasicClick',         name: 'BasicClick'},
          {path: '/example/BasicMethods',       name: 'BasicMethods'}
        ]
      }
    }
}
</script>


