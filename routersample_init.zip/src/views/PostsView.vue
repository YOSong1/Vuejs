<template>
  <div class="posts">
    <h1>Posts</h1>
    <p>안녕하세요. Vue로 만든 페이지 입니다.</p>
  </div>
</template>
