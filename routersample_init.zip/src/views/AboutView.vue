<template>
  <div class="about">
    <h1>About</h1>    
    <p>Vue로 만든 페이지 입니다.</p>
  </div>
</template>
