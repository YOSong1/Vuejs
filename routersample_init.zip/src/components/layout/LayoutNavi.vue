<template>
  <nav>
    <router-link to="/">Home</router-link> |
    <router-link to="/posts">Posts</router-link> | <!-- posts 추가 -->
    <router-link to="/users">Users</router-link> | <!-- users 추가 -->
    <router-link to="/example/InputForm">Vue 예제</router-link> |<!-- vue 예제 추가 -->
    <router-link to="/about">About</router-link><!-- about 추가 -->
  </nav>
</template>


