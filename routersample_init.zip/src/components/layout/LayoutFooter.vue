<template>
  <footer>
    <div>© 2024 </div>
    <div class="footer-nav"> 
      
      <a href="https://developer.mozilla.org/ko/docs/Web/JavaScript/Reference/Global_Objects/Array/slice" target="_blank">Vue Method</a> &nbsp;|&nbsp;
      <a href="https://github.com" target="_blank">Vue Beginning</a> &nbsp;|&nbsp;      
      <a href="https://router.vuejs.org/guide/essentials/dynamic-matching.html" target="_blank">Vue Router</a> &nbsp;|&nbsp;
      <a href="https://vuejs.org/examples/#hello-world" target="_blank">Vue Basic</a> &nbsp;|&nbsp; 
      <a href="https://bootstrap-vue.org/docs/components" target="_blank">Bootstrap-Vue</a>
    </div> 
  </footer>
</template>



