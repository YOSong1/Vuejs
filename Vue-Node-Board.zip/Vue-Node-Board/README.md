# Vue.js + Node.js + mysql로 게시판 만들기

## 구현 기능

- Front Server(Vue.js)와 Back Server(Node.js)로 구분
  - Front Server URL : http://127.0.0.1:8080
  - Back Server URL : http://127.0.0.1:52273
- 게시판 1, 2, 3 생성
- 각각의 게시판 별로 글 작성, 조회 가능
- 게시글 CRUD 구현
- 페이징 기능 구현
- 검색 기능 구현
- 이미지 업로드 기능 구현

## DataBase 설치

- Mysql Server 설치
- 현재 세팅된 정보 내용 확인 위치
  - node-back의 config.json에서 확인 가능
    "username": "root"
    "password": "1234"
    "database": "board"
